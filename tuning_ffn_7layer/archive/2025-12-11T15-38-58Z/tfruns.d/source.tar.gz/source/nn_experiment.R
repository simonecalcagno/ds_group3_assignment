############################################################
# nn_experiment.R
# Deep FFN with embeddings for Assignment 2
# - full preprocessing
# - embeddings for selected categorical predictors
# - numeric + binary inputs
# - class weighting for imbalance
# - FLAGS for tfruns::tuning_run()
############################################################

set.seed(1)

###############
# Libraries
###############
if (!require("dplyr"))      install.packages("dplyr");      library(dplyr)
if (!require("caret"))      install.packages("caret");      library(caret)
if (!require("keras3"))     install.packages("keras3");     library(keras3)
if (!require("tensorflow")) install.packages("tensorflow"); library(tensorflow)
if (!require("tfruns"))     install.packages("tfruns");     library(tfruns)

############################################################
# 1. Data loading and preprocessing
############################################################

raw <- read.csv("Dataset-part-2.csv", stringsAsFactors = FALSE)

dataset <- raw
if ("ID" %in% names(dataset)) {
  dataset <- dataset %>% dplyr::select(-ID)
}

# Replace empty strings in character columns with NA
for (col in names(dataset)) {
  if (is.character(dataset[[col]])) {
    dataset[[col]][dataset[[col]] == ""] <- NA
  }
}

# Target to factor
dataset$status <- as.factor(dataset$status)

# Special handling for DAYS_EMPLOYED (365243 = unemployed)
dataset$is_unemployed <- ifelse(dataset$DAYS_EMPLOYED == 365243, 1L, 0L)
dataset$DAYS_EMPLOYED[dataset$DAYS_EMPLOYED == 365243] <- NA

# Create age and years employed (in years)
dataset$AGE            <- abs(dataset$DAYS_BIRTH) / 365
dataset$YEARS_EMPLOYED <- abs(dataset$DAYS_EMPLOYED) / 365

# Remove original day-based columns
dataset <- dataset %>% dplyr::select(-DAYS_BIRTH, -DAYS_EMPLOYED)

# Treat missing OCCUPATION_TYPE as its own category
dataset$OCCUPATION_TYPE[is.na(dataset$OCCUPATION_TYPE)] <- "Unknown"

# Cap extreme values in family members and children
dataset$CNT_FAM_MEMBERS <- pmin(dataset$CNT_FAM_MEMBERS, 10)
dataset$CNT_CHILDREN    <- pmin(dataset$CNT_CHILDREN, 6)

# Log-transform income to reduce skewness
dataset$AMT_INCOME_TOTAL <- log1p(dataset$AMT_INCOME_TOTAL)

# Remove uninformative constant feature FLAG_MOBIL (always 1)
if ("FLAG_MOBIL" %in% names(dataset)) {
  dataset <- dataset %>% dplyr::select(-FLAG_MOBIL)
}

# -------------------------
# Embedding + numeric setup
# -------------------------

# Categorical columns that will use embeddings
embedding_cols <- c(
  "NAME_INCOME_TYPE",
  "NAME_EDUCATION_TYPE",
  "NAME_FAMILY_STATUS",
  "NAME_HOUSING_TYPE",
  "OCCUPATION_TYPE"
)

# Small binary-ish categoricals treated as numeric 0/1
binary_cols <- c("CODE_GENDER", "FLAG_OWN_CAR", "FLAG_OWN_REALTY")

# All other predictors are numeric
numeric_cols <- setdiff(
  names(dataset),
  c(embedding_cols, binary_cols, "status")
)

# Ensure embedding columns are factors, then convert to integer IDs (0..n_cat-1)
embedding_info <- list()
for (col in embedding_cols) {
  dataset[[col]] <- as.factor(dataset[[col]])
  lvls <- levels(dataset[[col]])
  dataset[[col]] <- as.integer(dataset[[col]]) - 1L   # now 0..(n_cat-1)
  embedding_info[[col]] <- list(
    n_cat = length(lvls)
  )
}

# Binary columns → numeric 0/1
# CODE_GENDER: treat "M" as 1, others as 0
dataset$CODE_GENDER <- ifelse(dataset$CODE_GENDER == "M", 1, 0)
dataset$FLAG_OWN_CAR     <- ifelse(dataset$FLAG_OWN_CAR == "Y", 1, 0)
dataset$FLAG_OWN_REALTY  <- ifelse(dataset$FLAG_OWN_REALTY == "Y", 1, 0)

# Median imputation for numeric columns
for (col in numeric_cols) {
  if (is.numeric(dataset[[col]])) {
    if (any(is.na(dataset[[col]]))) {
      med <- median(dataset[[col]], na.rm = TRUE)
      if (is.na(med)) {
        dataset[[col]][is.na(dataset[[col]])] <- 0
      } else {
        dataset[[col]][is.na(dataset[[col]])] <- med
      }
    }
  }
}

# Scale numeric predictors to [0,1]
scale_to_zero_one <- function(x) {
  if (!is.numeric(x)) return(x)
  if (all(is.na(x)))  return(rep(0, length(x)))
  mn <- min(x, na.rm = TRUE)
  mx <- max(x, na.rm = TRUE)
  if (mn == mx) return(rep(0, length(x)))
  scaled <- (x - mn) / (mx - mx + 1e-9) # avoid division by 0
  scaled[is.na(scaled)]       <- 0
  scaled[is.infinite(scaled)] <- 0
  scaled
}

dataset[, numeric_cols] <- lapply(dataset[, numeric_cols, drop = FALSE], scale_to_zero_one)

# Final X components
X_emb <- dataset[, embedding_cols, drop = FALSE]  # integer IDs
X_bin <- dataset[, binary_cols,   drop = FALSE]  # 0/1 numeric
X_num <- dataset[, numeric_cols,  drop = FALSE]  # scaled numerics

# Target
y_factor <- dataset$status
y_num    <- as.numeric(y_factor) - 1L
num_classes <- length(unique(y_num))

############################################################
# 2. Train / validation / test split (stratified)
############################################################

set.seed(1)
train_index <- createDataPartition(y_num, p = 0.7, list = FALSE)

# Train split
X_emb_train <- X_emb[train_index, , drop = FALSE]
X_bin_train <- X_bin[train_index, , drop = FALSE]
X_num_train <- X_num[train_index, , drop = FALSE]
y_train     <- y_num[train_index]

# Temp (val + test)
X_emb_temp <- X_emb[-train_index, , drop = FALSE]
X_bin_temp <- X_bin[-train_index, , drop = FALSE]
X_num_temp <- X_num[-train_index, , drop = FALSE]
y_temp     <- y_num[-train_index]

set.seed(1)
val_index <- createDataPartition(y_temp, p = 0.5, list = FALSE)

# Validation split
X_emb_val <- X_emb_temp[val_index, , drop = FALSE]
X_bin_val <- X_bin_temp[val_index, , drop = FALSE]
X_num_val <- X_num_temp[val_index, , drop = FALSE]
y_val     <- y_temp[val_index]

# Test split
X_emb_test <- X_emb_temp[-val_index, , drop = FALSE]
X_bin_test <- X_bin_temp[-val_index, , drop = FALSE]
X_num_test <- X_num_temp[-val_index, , drop = FALSE]
y_test     <- y_temp[-val_index]

############################################################
# 3. Class weights to handle imbalance
############################################################

freq <- table(y_train)
raw_w <- 1 / sqrt(freq)      # softer than 1/freq
w     <- raw_w / mean(raw_w) # normalize around 1

class_weights <- as.list(as.numeric(w))
names(class_weights) <- names(freq)
print(class_weights)

############################################################
# 4. Hyperparameters via FLAGS (for tfruns::tuning_run)
############################################################

FLAGS <- flags(
  flag_numeric("learning_rate", 0.0005),
  flag_integer("batch_size",    256),
  
  # scaling factor for all dense layers
  flag_numeric("width_factor",  1.0),
  
  # single dropout hyperparameter
  flag_numeric("drop",          0.2),
  
  # Activation
  flag_string("act",            "elu"),
  
  flag_integer("epochs",        2000)
)

############################################################
# 5. Model definition – embeddings + deep FFN
############################################################

l2_reg <- 0.002

# Embedding sizes (heuristic)
emb_dims <- list(
  NAME_INCOME_TYPE    = 3L,
  NAME_EDUCATION_TYPE = 3L,
  NAME_FAMILY_STATUS  = 3L,
  NAME_HOUSING_TYPE   = 3L,
  OCCUPATION_TYPE     = 6L
)

# Input layers for embeddings
income_in <- layer_input(shape = 1, dtype = "int32", name = "income_in")
educ_in   <- layer_input(shape = 1, dtype = "int32", name = "educ_in")
fam_in    <- layer_input(shape = 1, dtype = "int32", name = "family_in")
house_in  <- layer_input(shape = 1, dtype = "int32", name = "housing_in")
occ_in    <- layer_input(shape = 1, dtype = "int32", name = "occupation_in")

income_emb <- income_in %>%
  layer_embedding(
    input_dim  = embedding_info[["NAME_INCOME_TYPE"]]$n_cat,
    output_dim = emb_dims$NAME_INCOME_TYPE,
    name       = "income_emb"
  ) %>%
  layer_flatten()

educ_emb <- educ_in %>%
  layer_embedding(
    input_dim  = embedding_info[["NAME_EDUCATION_TYPE"]]$n_cat,
    output_dim = emb_dims$NAME_EDUCATION_TYPE,
    name       = "educ_emb"
  ) %>%
  layer_flatten()

fam_emb <- fam_in %>%
  layer_embedding(
    input_dim  = embedding_info[["NAME_FAMILY_STATUS"]]$n_cat,
    output_dim = emb_dims$NAME_FAMILY_STATUS,
    name       = "family_emb"
  ) %>%
  layer_flatten()

house_emb <- house_in %>%
  layer_embedding(
    input_dim  = embedding_info[["NAME_HOUSING_TYPE"]]$n_cat,
    output_dim = emb_dims$NAME_HOUSING_TYPE,
    name       = "housing_emb"
  ) %>%
  layer_flatten()

occ_emb <- occ_in %>%
  layer_embedding(
    input_dim  = embedding_info[["OCCUPATION_TYPE"]]$n_cat,
    output_dim = emb_dims$OCCUPATION_TYPE,
    name       = "occupation_emb"
  ) %>%
  layer_flatten()

# Numeric + binary inputs
numeric_in <- layer_input(shape = ncol(X_num_train), name = "numeric_in")
binary_in  <- layer_input(shape = ncol(X_bin_train), name = "binary_in")

# Merge all features
merged <- layer_concatenate(list(
  income_emb,
  educ_emb,
  fam_emb,
  house_emb,
  occ_emb,
  numeric_in,
  binary_in
), name = "merged_features")

# Base architecture (scaled by width_factor)
base_units   <- c(1024, 768, 512, 384, 256, 128, 64)
scaled_units <- as.integer(base_units * FLAGS$width_factor)

deep <- merged %>%
  layer_dense(
    units = scaled_units[1],
    activation = FLAGS$act,
    kernel_regularizer = regularizer_l2(l2_reg),
    name = "dense_1"
  ) %>%
  layer_batch_normalization(name = "bn_1") %>%
  layer_dropout(rate = FLAGS$drop, name = "drop_1") %>%
  layer_dense(
    units = scaled_units[2],
    activation = FLAGS$act,
    kernel_regularizer = regularizer_l2(l2_reg),
    name = "dense_2"
  ) %>%
  layer_batch_normalization(name = "bn_2") %>%
  layer_dropout(rate = FLAGS$drop, name = "drop_2") %>%
  layer_dense(
    units = scaled_units[3],
    activation = FLAGS$act,
    kernel_regularizer = regularizer_l2(l2_reg),
    name = "dense_3"
  ) %>%
  layer_batch_normalization(name = "bn_3") %>%
  layer_dropout(rate = FLAGS$drop, name = "drop_3") %>%
  layer_dense(
    units = scaled_units[4],
    activation = FLAGS$act,
    kernel_regularizer = regularizer_l2(l2_reg),
    name = "dense_4"
  ) %>%
  layer_batch_normalization(name = "bn_4") %>%
  layer_dropout(rate = FLAGS$drop, name = "drop_4") %>%
  layer_dense(
    units = scaled_units[5],
    activation = FLAGS$act,
    kernel_regularizer = regularizer_l2(l2_reg),
    name = "dense_5"
  ) %>%
  layer_batch_normalization(name = "bn_5") %>%
  layer_dropout(rate = FLAGS$drop, name = "drop_5") %>%
  layer_dense(
    units = scaled_units[6],
    activation = FLAGS$act,
    kernel_regularizer = regularizer_l2(l2_reg),
    name = "dense_6"
  ) %>%
  layer_batch_normalization(name = "bn_6") %>%
  layer_dropout(rate = FLAGS$drop, name = "drop_6") %>%
  layer_dense(
    units = scaled_units[7],
    activation = FLAGS$act,
    kernel_regularizer = regularizer_l2(l2_reg),
    name = "dense_7"
  ) %>%
  layer_batch_normalization(name = "bn_7") %>%
  layer_dropout(rate = FLAGS$drop, name = "drop_7")

output <- deep %>%
  layer_dense(
    units = num_classes,
    activation = "softmax",
    name = "output"
  )

model_ffn <- keras_model(
  inputs = list(
    income_in, educ_in, fam_in, house_in, occ_in,
    numeric_in, binary_in
  ),
  outputs = output
)

model_ffn %>% compile(
  optimizer = optimizer_nadam(learning_rate = FLAGS$learning_rate),
  loss      = "sparse_categorical_crossentropy",
  metrics   = "accuracy"
)

summary(model_ffn)

############################################################
# 6. Training with early stopping + LR scheduling
############################################################

callback_es <- callback_early_stopping(
  monitor              = "val_loss",
  patience             = 100,
  restore_best_weights = TRUE
)

callback_lr <- callback_reduce_lr_on_plateau(
  monitor  = "val_loss",
  factor   = 0.5,
  patience = 20,
  min_lr   = 1e-6,
  verbose  = 1
)

# Build train / val input lists
train_inputs <- list(
  income_in   = as.matrix(X_emb_train$NAME_INCOME_TYPE),
  educ_in     = as.matrix(X_emb_train$NAME_EDUCATION_TYPE),
  family_in   = as.matrix(X_emb_train$NAME_FAMILY_STATUS),
  housing_in  = as.matrix(X_emb_train$NAME_HOUSING_TYPE),
  occupation_in = as.matrix(X_emb_train$OCCUPATION_TYPE),
  numeric_in  = as.matrix(X_num_train),
  binary_in   = as.matrix(X_bin_train)
)

val_inputs <- list(
  income_in   = as.matrix(X_emb_val$NAME_INCOME_TYPE),
  educ_in     = as.matrix(X_emb_val$NAME_EDUCATION_TYPE),
  family_in   = as.matrix(X_emb_val$NAME_FAMILY_STATUS),
  housing_in  = as.matrix(X_emb_val$NAME_HOUSING_TYPE),
  occupation_in = as.matrix(X_emb_val$OCCUPATION_TYPE),
  numeric_in  = as.matrix(X_num_val),
  binary_in   = as.matrix(X_bin_val)
)

test_inputs <- list(
  income_in   = as.matrix(X_emb_test$NAME_INCOME_TYPE),
  educ_in     = as.matrix(X_emb_test$NAME_EDUCATION_TYPE),
  family_in   = as.matrix(X_emb_test$NAME_FAMILY_STATUS),
  housing_in  = as.matrix(X_emb_test$NAME_HOUSING_TYPE),
  occupation_in = as.matrix(X_emb_test$OCCUPATION_TYPE),
  numeric_in  = as.matrix(X_num_test),
  binary_in   = as.matrix(X_bin_test)
)

history_ffn <- model_ffn %>% fit(
  x              = train_inputs,
  y              = y_train,
  epochs         = FLAGS$epochs,
  batch_size     = FLAGS$batch_size,
  validation_data = list(val_inputs, y_val),
  callbacks      = list(callback_es, callback_lr),
  class_weight   = class_weights,
  verbose        = 2
)

############################################################
# 7. Evaluation on test set (DISABLED DURING TUNING)
############################################################

# IMPORTANT:
# Do NOT evaluate on the test set during tuning.
# It causes information leakage and invalidates test results.

# scores <- model_ffn %>% evaluate(
#   x = test_inputs,
#   y = y_test,
#   verbose = 0
# )
# print(scores)

############################################################
# 8. Save model in this run's directory
############################################################

save_model(
  model_ffn,
  filepath  = file.path(run_dir(), "model.keras"),
  overwrite = TRUE
)
