################################################################################
# nn_safety_first.R
# Strategy: "Stability & Safety"
# - Fixes the 'loss: nan' crash.
# - Uses Batch Normalization to stabilize the One-Hot features.
# - Uses Adam (safer than SGD) to navigate the sparse data.
################################################################################

set.seed(42)

# --- Libraries ---
if (!require("dplyr")) install.packages("dplyr")
library(dplyr)
if (!require("caret")) install.packages("caret")
library(caret)
if (!require("keras3")) install.packages("keras3")
library(keras3)
if (!require("tensorflow")) install.packages("tensorflow")
library(tensorflow)

################################################################################
# 1. Data Prep & Sanitation
################################################################################

raw <- read.csv("Dataset-part-2.csv", stringsAsFactors = FALSE)
dataset <- raw

if ("ID" %in% names(dataset)) dataset <- dataset %>% select(-ID)
dataset <- unique(dataset) 

# Basic Cleanup
for (col in names(dataset)) {
  if (is.character(dataset[[col]])) {
    dataset[[col]][dataset[[col]] == ""] <- "Unknown"
    dataset[[col]][is.na(dataset[[col]])] <- "Unknown"
  }
}

# Fixes
dataset$is_unemployed <- ifelse(dataset$DAYS_EMPLOYED == 365243, 1L, 0L)
dataset$DAYS_EMPLOYED[dataset$DAYS_EMPLOYED == 365243] <- NA
dataset$AGE_YEARS <- abs(dataset$DAYS_BIRTH) / 365
dataset$YEARS_EMPLOYED <- abs(dataset$DAYS_EMPLOYED) / 365
dataset$AGE_YEARS <- pmin(dataset$AGE_YEARS, 90)
dataset$YEARS_EMPLOYED <- pmin(dataset$YEARS_EMPLOYED, 60)
dataset <- dataset %>% select(-DAYS_BIRTH, -DAYS_EMPLOYED)

# --- Feature Engineering (Safe Version) ---
# We add +1 to denominators to prevent Division by Zero (which causes NaN)
if (all(c("AMT_CREDIT", "AMT_INCOME_TOTAL") %in% names(dataset))) {
  dataset$CREDIT_TO_INCOME <- dataset$AMT_CREDIT / (dataset$AMT_INCOME_TOTAL + 1)
}
if (all(c("AMT_ANNUITY", "AMT_INCOME_TOTAL") %in% names(dataset))) {
  dataset$ANNUITY_TO_INCOME <- dataset$AMT_ANNUITY / (dataset$AMT_INCOME_TOTAL + 1)
}
if (all(c("AMT_INCOME_TOTAL", "CNT_FAM_MEMBERS") %in% names(dataset))) {
  dataset$INCOME_PER_FAMILY <- dataset$AMT_INCOME_TOTAL / pmax(dataset$CNT_FAM_MEMBERS, 1)
}

# Log Transforms (Safe)
numeric_cols_to_log <- c("AMT_INCOME_TOTAL", "AMT_CREDIT", "AMT_ANNUITY", "AMT_GOODS_PRICE", "AGE_YEARS")
for (col in numeric_cols_to_log) {
  if (col %in% names(dataset)) {
    dataset[[col]] <- log1p(pmax(0, dataset[[col]], na.rm = TRUE))
  }
}

################################################################################
# 2. Encoding & Scaling
################################################################################

target_col <- "status"
dataset$status_idx <- as.numeric(factor(dataset$status)) - 1
num_classes <- length(unique(dataset$status_idx))
target_vals <- dataset$status_idx
dataset$status <- NULL
dataset$status_idx <- NULL

# One-Hot Encoding
cat("One-Hot Encoding...\n")
dummies <- dummyVars(~ ., data = dataset)
dataset_onehot <- predict(dummies, newdata = dataset)
dataset_onehot <- as.data.frame(dataset_onehot)
dataset_onehot$status_idx <- target_vals

# Splits
final_split_idx <- createDataPartition(dataset_onehot$status_idx, p = 0.85, list = FALSE)
data_dev  <- dataset_onehot[final_split_idx, ] 
data_test <- dataset_onehot[-final_split_idx, ] 

train_idx <- createDataPartition(data_dev$status_idx, p = 0.8, list = FALSE)
data_train <- data_dev[train_idx, ]
data_val   <- data_dev[-train_idx, ]

# Scaling
numeric_cols <- setdiff(names(data_train), "status_idx")
preproc <- preProcess(data_train[, numeric_cols], method = c("range")) # MinMax 0-1

data_train[, numeric_cols] <- predict(preproc, data_train[, numeric_cols])
data_val[, numeric_cols]   <- predict(preproc, data_val[, numeric_cols])
data_test[, numeric_cols]  <- predict(preproc, data_test[, numeric_cols])

# --- THE SANITATION STEP (CRITICAL) ---
# This purges the 'Infs' and 'NaNs' that crashed the previous run.
sanitize_matrix <- function(df) {
  mat <- as.matrix(df %>% select(-status_idx))
  mat[is.na(mat)] <- 0
  mat[is.infinite(mat)] <- 0
  return(mat)
}

x_train <- sanitize_matrix(data_train)
y_train <- to_categorical(data_train$status_idx, num_classes)
x_val   <- sanitize_matrix(data_val)
y_val   <- to_categorical(data_val$status_idx, num_classes)
x_test  <- sanitize_matrix(data_test)
y_test  <- to_categorical(data_test$status_idx, num_classes)

################################################################################
# 3. Architecture: The Stable Block
################################################################################

input_shape <- ncol(x_train)

# We use BatchNormalization() immediately after Dense() to keep weights stable.
model <- keras_model_sequential() %>%
  layer_dense(units = 1024, input_shape = c(input_shape)) %>%
  
  layer_activation("relu") %>%

  
  layer_dense(units = 512) %>%

  layer_activation("relu") %>%

  
  layer_dense(units = num_classes, activation = "softmax")

# ADAM OPTIMIZER
# We switch to Adam because it handles sparse data (One-Hot) better than SGD.
model %>% compile(
  optimizer = optimizer_adam(learning_rate = 0.001), 
  loss = "categorical_crossentropy", 
  metrics = "accuracy"
)

################################################################################
# 4. Training
################################################################################

cat("Starting Safe Marathon...\n")

model %>% fit(
  x_train, y_train, 
  epochs = 200,          # Adam is fast, 200 epochs is plenty
  batch_size = 256, 
  validation_data = list(x_val, y_val),
  callbacks = list(
    callback_early_stopping(monitor = "val_loss", patience = 20, restore_best_weights = TRUE)
  ),
  verbose = 2
)

cat("\n--- SAFE RESULT ---\n")
scores <- model %>% evaluate(x_test, y_test, verbose=0)
cat("Test Accuracy:", if(is.list(scores)) scores$accuracy else scores[[2]], "\n")

# Confusion Matrix
pred_probs <- model %>% predict(x_test)
pred_classes <- apply(pred_probs, 1, which.max) - 1
status_levels <- levels(factor(raw$status))
pred_f <- factor(status_levels[pred_classes + 1], levels = status_levels)
true_f <- factor(status_levels[data_test$status_idx + 1], levels = status_levels)
print(confusionMatrix(pred_f, true_f))
save_model(model, "safety_first_model.keras")